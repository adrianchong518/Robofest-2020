#include <GY53.h>

GY53::GY53(HardwareSerial *const serial, const unsigned long baudRate)
    : m_serial(serial), m_baudRate(baudRate) {}

GY53::~GY53() {}

void GY53::init() { m_serial->begin(m_baudRate); }

void GY53::update() {
  if (m_serial->available()) {
    m_inBuffer[m_inLen] = (byte)m_serial->read();
    if (m_inLen == 0 && m_inBuffer[0] != 0x5A) {
      return;
    }
    if (m_inLen == 1 && m_inBuffer[1] != 0x5A) {
      m_inLen = 0;
      return;
    }

    if (++m_inLen == 8) {
      parseData();
      m_inLen = 0;
    }
  }
}

uint16_t GY53::getDistance() const { return m_distance; }

byte GY53::getMode() const { return m_mode; }

void GY53::setMode(const byte mode) {
  if (mode >= 0 && mode <= 3) {
    m_serial->write(0xA5);
    m_serial->write(0x50 + mode);
    m_serial->write(0xF5 + mode);
  }
}

void GY53::parseData() {
  byte checkSum = 0;

  for (int i = 0; i < 7; i++) {
    checkSum += m_inBuffer[i];
  }

  if (checkSum == m_inBuffer[7]) {
    m_distance = m_inBuffer[4] << 8 | m_inBuffer[5];
    m_mode = m_inBuffer[6];
  }
}
