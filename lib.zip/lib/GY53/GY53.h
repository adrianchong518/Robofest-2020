#ifndef GY53_H
#define GY53_H

#include <Arduino.h>

class GY53 {
 private:
  HardwareSerial *const m_serial;

  byte m_inBuffer[8];
  byte m_inLen = 0;

  uint16_t m_distance;
  uint8_t m_mode;

 public:
  GY53(HardwareSerial *const serial, const unsigned long baudRate,
       const byte mode = 3);

  ~GY53();

  void update();

  uint16_t getDistance() const;

  byte getMode() const;
  void setMode(const byte mode);

 private:
  void parseData();
};

#endif  // GY53_H