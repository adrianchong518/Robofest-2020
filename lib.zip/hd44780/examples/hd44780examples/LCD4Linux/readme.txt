https://lcd4linux.bulix.org/
https://lcd4linux.bulix.org/wiki/Displays
https://github.com/ZivaVatra/ArduLCD
