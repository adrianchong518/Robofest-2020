Documenation sketch
===================
The Documenation.ino sketch is not really an example sketch.  
It is a dummy sketch used to allow documentation to be accessed through the IDE when the sketched is loaded into the IDE.
