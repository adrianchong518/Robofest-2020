#ifndef STEPPER_H
#define STEPPER_H

#include <Arduino.h>

class Stepper {
 public:
  enum CODES {
    NO_ERROR,
    ERROR_TARGET_EXCEEDS_LIMIT,
    ERROR_PULSE_WIDTH_EXCEEDS_LIMIT
  };

  enum CONTROL_TYPES { CW_CCW_PULSE, PULSE_DIR };

  static const unsigned long PULSE_WIDTH = 1000;

 private:
  CONTROL_TYPES m_controlType;

  unsigned long m_prevPulseTime;

  uint8_t m_prevState;

 protected:
  uint8_t m_pin_control1;
  uint8_t m_pin_control2;

  bool m_isStepLimitEnabled = false;
  long m_stepLowerLimit = 0;
  long m_stepUpperLimit = 0;

  unsigned long m_minPulseWidth = 1;
  unsigned long m_maxPulseWidth = PULSE_WIDTH;

  unsigned int m_pulseWidth = PULSE_WIDTH;

  long m_location = 0;
  long m_target = 0;
  unsigned long m_targetDiff = 0;

  bool m_isTargetReached;

 public:
  Stepper(const uint8_t pin_control1, const uint8_t pin_control2,
          const CONTROL_TYPES controlType);
  ~Stepper();

  void update();
  bool genPulse(int dir);

  long getLocation();

  void setHomePosition();

  void setStepLimitEnabled(const bool isStepLimitEnabled);
  void setStepLimit(const long stepLowerLimit, const long stepUpperLimit);

  CODES setTarget(const long target);

  bool isTargetReached();

  void setPulseWidthLimit(const unsigned long minPulseWidth,
                          const unsigned long maxPulseWidth);
  CODES setPulseWidth(const unsigned long pulseWidth);
  unsigned long getPulseWidth();

 protected:
  virtual void home(const unsigned long pulseWidth) = 0;

 private:
  bool genPulse__CW_CCW_PULSE(int dir);
  bool genPulse__PULSE_DIR(int dir);
};

#endif  // STEPPER_H
