#include "Stepper.h"

Stepper::Stepper(const uint8_t pin_control1, const uint8_t pin_control2,
                 const Stepper::CONTROL_TYPES controlType) {
  m_pin_control1 = pin_control1;
  m_pin_control2 = pin_control2;
  m_controlType = controlType;

  pinMode(m_pin_control1, OUTPUT);
  pinMode(m_pin_control2, OUTPUT);

  digitalWrite(m_pin_control1, LOW);
  digitalWrite(m_pin_control2, LOW);

  m_location = 0;
}

Stepper::~Stepper() {}

void Stepper::update() {
  m_isTargetReached = m_location == m_target;
  if (!m_isTargetReached) {
    int dir = m_target - m_location > 0 ? 1 : -1;
    if (genPulse(dir)) {
      m_location += dir;
    }
  } else {
    digitalWrite(m_pin_control1, LOW);
    digitalWrite(m_pin_control2, LOW);
  }
}

bool Stepper::genPulse(int dir) {
  bool isPulseEnded;

  unsigned long currTime = micros();
  if (currTime - m_prevPulseTime >= m_pulseWidth / 2) {
    switch (m_controlType) {
      case CW_CCW_PULSE:
        isPulseEnded = genPulse__CW_CCW_PULSE(dir);
        break;
      case PULSE_DIR:
        isPulseEnded = genPulse__PULSE_DIR(dir);
        break;
    }

    m_prevPulseTime = currTime;
  }

  return isPulseEnded;
}

bool Stepper::genPulse__CW_CCW_PULSE(int dir) {
  bool isPulseEnded = false;

  if (dir == 1) {
    if (m_prevState == LOW) {
      digitalWrite(m_pin_control1, HIGH);
      m_prevState = HIGH;
    } else {
      digitalWrite(m_pin_control1, LOW);
      isPulseEnded = true;
      m_prevState = LOW;
    }
  } else if (dir == -1) {
    if (m_prevState == LOW) {
      digitalWrite(m_pin_control2, HIGH);
      m_prevState = HIGH;
    } else {
      digitalWrite(m_pin_control2, LOW);
      isPulseEnded = true;
      m_prevState = LOW;
    }
  }

  return isPulseEnded;
}

bool Stepper::genPulse__PULSE_DIR(int dir) {
  bool isPulseEnded = false;

  if (dir == 1) {
    digitalWrite(m_pin_control2, LOW);
    if (m_prevState == LOW) {
      digitalWrite(m_pin_control1, HIGH);
      m_prevState = HIGH;
    } else {
      digitalWrite(m_pin_control1, LOW);
      isPulseEnded = true;
      m_prevState = LOW;
    }
  } else if (dir == -1) {
    digitalWrite(m_pin_control2, HIGH);
    if (m_prevState == LOW) {
      digitalWrite(m_pin_control1, HIGH);
      m_prevState = HIGH;
    } else {
      digitalWrite(m_pin_control1, LOW);
      isPulseEnded = true;
      m_prevState = LOW;
    }
  }

  return isPulseEnded;
}

long Stepper::getLocation() { return m_location; }

void Stepper::setStepLimitEnabled(const bool isStepLimitEnabled) {
  m_isStepLimitEnabled = isStepLimitEnabled;
}

void Stepper::setHomePosition() {
  m_location = 0;
  m_target = 0;
}

void Stepper::setStepLimit(const long stepLowerLimit,
                           const long stepUpperLimit) {
  m_stepLowerLimit = stepLowerLimit;
  m_stepUpperLimit = stepUpperLimit;
}

Stepper::CODES Stepper::setTarget(const long target) {
  if (m_isStepLimitEnabled &&
      (target > m_stepUpperLimit || target < m_stepLowerLimit)) {
    return CODES::ERROR_TARGET_EXCEEDS_LIMIT;
  }

  m_target = target;
  m_targetDiff = abs(m_target - m_location);
  setPulseWidth(PULSE_WIDTH);

  digitalWrite(m_pin_control1, LOW);
  digitalWrite(m_pin_control2, LOW);
  m_prevState = LOW;

  return CODES::NO_ERROR;
}

bool Stepper::isTargetReached() { return m_target == m_location; }

void Stepper::setPulseWidthLimit(const unsigned long minPulseWidth,
                                 const unsigned long maxPulseWidth) {
  m_minPulseWidth = minPulseWidth;
  m_maxPulseWidth = maxPulseWidth;
}

Stepper::CODES Stepper::setPulseWidth(const unsigned long pulseWidth) {
  if (pulseWidth < m_minPulseWidth || pulseWidth > m_maxPulseWidth) {
    return ERROR_PULSE_WIDTH_EXCEEDS_LIMIT;
  }

  m_pulseWidth = pulseWidth;
  return NO_ERROR;
}

unsigned long Stepper::getPulseWidth() { return m_pulseWidth; }
